<?php
require 'connection.php';
session_start();
$userType = $_POST['userType'];
$user = $_POST['email'];
$pass = $_POST['password'];

if($userType=="driver"){
  $query = "select password,status from driver where email = '$user';";
  $result = $conn->query($query);
  if($row = $result->fetch_assoc()){

    if($row['password']==$pass && $row['status']==0){

      $_SESSION['driverEmail']=$user;
        header("Location:Driver.php");
    }else {
      header("Location:Fail.php");
    }
  }else{
    header("Location:Fail.php");
  }
}else{
$query = "select pass,status from passenger where email = '$user';";
$result = $conn->query($query);
if($row = $result->fetch_assoc()){

  if($row['pass']==$pass && $row['status']==0){
      $_SESSION['passengerEmail']=$user;
      header("Location:Passenger.php");
  }else {
      header("Location:Fail.php");
  }
}else{
  header("Location:Fail.php");
}
}

 ?>
