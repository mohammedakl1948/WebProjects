-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 30, 2022 at 03:32 PM
-- Server version: 8.0.21
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car_pooling`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `email` varchar(150) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`) VALUES
('mohammedakl680@gmail.com', 'Mohammed.123');

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

DROP TABLE IF EXISTS `driver`;
CREATE TABLE IF NOT EXISTS `driver` (
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `rating` varchar(255) DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`name`, `phone`, `email`, `password`, `address`, `rating`, `status`) VALUES
(NULL, NULL, '', NULL, NULL, NULL, 0),
('mohammedakl', '76712486', 'mohammedakl6671@gmail.com', 'mohammed', 'saida', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `driveremergencycontacts`
--

DROP TABLE IF EXISTS `driveremergencycontacts`;
CREATE TABLE IF NOT EXISTS `driveremergencycontacts` (
  `did` varchar(150) NOT NULL,
  `contactName` varchar(255) DEFAULT NULL,
  `contactPhone` varchar(255) DEFAULT NULL,
  `contactEmail` varchar(255) DEFAULT NULL,
  KEY `did` (`did`),
  KEY `did_2` (`did`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

DROP TABLE IF EXISTS `newsletter`;
CREATE TABLE IF NOT EXISTS `newsletter` (
  `emailid` varchar(150) NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`emailid`) VALUES
(''),
('mohammed@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

DROP TABLE IF EXISTS `passenger`;
CREATE TABLE IF NOT EXISTS `passenger` (
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `phonenumber` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `status` varchar(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`name`, `email`, `phonenumber`, `pass`, `address`, `status`) VALUES
(NULL, '', NULL, NULL, NULL, '1'),
('mohammedakl', 'mohammedakl6671@gmail.com', '76712486', '1111111111111', 'saida', '0'),
('ahmadsha3ban', 'ah.sh@gmail.com', '81624873', 'Ahmad.123', 'Saida,Lebanon', '0');

-- --------------------------------------------------------

--
-- Table structure for table `passengeremergencycontacts`
--

DROP TABLE IF EXISTS `passengeremergencycontacts`;
CREATE TABLE IF NOT EXISTS `passengeremergencycontacts` (
  `pid` varchar(150) NOT NULL,
  `contactName` varchar(255) DEFAULT NULL,
  `contactPhone` varchar(255) DEFAULT NULL,
  `contactEmail` varchar(255) DEFAULT NULL,
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

DROP TABLE IF EXISTS `requests`;
CREATE TABLE IF NOT EXISTS `requests` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `PEmail` varchar(150) NOT NULL,
  `TID` int NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `PEmail` (`PEmail`),
  KEY `TID` (`TID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trip`
--

DROP TABLE IF EXISTS `trip`;
CREATE TABLE IF NOT EXISTS `trip` (
  `TID` int NOT NULL AUTO_INCREMENT,
  `datee` date DEFAULT NULL,
  `starttime` datetime DEFAULT NULL,
  `arrivetime` datetime DEFAULT NULL,
  `startinglocation` varchar(255) DEFAULT NULL,
  `destination` varchar(255) DEFAULT NULL,
  `DID` varchar(150) NOT NULL,
  `maxPassengers` int NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`TID`),
  KEY `DID` (`DID`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `trip`
--

INSERT INTO `trip` (`TID`, `datee`, `starttime`, `arrivetime`, `startinglocation`, `destination`, `DID`, `maxPassengers`, `status`) VALUES
(17, '2022-05-23', '2022-05-27 08:12:00', '2022-05-28 08:12:00', 'Saida', 'Beirut', 'mohammedakl6671@gmail.com', 4, 'progress'),
(15, '2022-05-22', '2022-06-04 20:50:00', '2022-06-04 20:51:00', 'Saida', 'Beirut', 'mohammedakl6671@gmail.com', 4, 'progress'),
(14, '2022-05-21', '2022-05-28 00:18:00', '2022-05-28 00:18:00', 'aaaaaaaaa', 'aaaaaaaaaaaaaaa', 'mohammedakl6671@gmail.com', 5, 'progress');

-- --------------------------------------------------------

--
-- Table structure for table `tripfeedback`
--

DROP TABLE IF EXISTS `tripfeedback`;
CREATE TABLE IF NOT EXISTS `tripfeedback` (
  `pID` varchar(150) NOT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `tID` int DEFAULT NULL,
  KEY `pID` (`pID`),
  KEY `tID` (`tID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trippassengers`
--

DROP TABLE IF EXISTS `trippassengers`;
CREATE TABLE IF NOT EXISTS `trippassengers` (
  `driverID` varchar(150) NOT NULL,
  `PID` varchar(150) NOT NULL,
  `TID` int NOT NULL,
  KEY `TID` (`TID`),
  KEY `PID` (`PID`),
  KEY `driverID` (`driverID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `trippassengers`
--

INSERT INTO `trippassengers` (`driverID`, `PID`, `TID`) VALUES
('mohammedakl6671@gmail.com', '', 15),
('mohammedakl6671@gmail.com', 'mohammedakl6671@gmail.com', 15),
('mohammedakl6671@gmail.com', 'mohammedakl6671@gmail.com', 17);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
