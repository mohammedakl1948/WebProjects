<?php




if($conn->query($query)){
  header("Location:Succesful.php");
}else{
  header("Location:Fail.php");
} ?>
