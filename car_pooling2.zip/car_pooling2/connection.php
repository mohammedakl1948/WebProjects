<?php

  $servername = "localhost";
  $user = "root";
  $pass="";
  $database = "car_pooling";

  $conn = new mysqli($servername , $user, $pass, $database);


 ?>
