<?php
require "checkDriver.php";

 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <!-- mobile metas -->
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="viewport" content="initial-scale=1, maximum-scale=1">
     <!-- site metas -->
     <title>Passenger</title>
     <meta name="keywords" content="">
     <meta name="description" content="">
     <meta name="author" content="">
     <!-- bootstrap css -->
     <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
     <!-- style css -->
     <link rel="stylesheet" type="text/css" href="css/style.css">
     <!-- Responsive-->
     <link rel="stylesheet" href="css/responsive.css">
     <!-- fevicon -->
     <link rel="icon" href="images/fevicon.png" type="image/gif" />
     <!-- Scrollbar Custom CSS -->
     <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
     <!-- Tweaks for older IEs-->
     <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
     <!-- owl stylesheets -->
     <link rel="stylesheet" href="css/owl.carousel.min.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
     <style media="screen">
     .btn-primary,
     .btn-primary:active,
     .btn-primary:visited,
     .btn-primary:focus {
       background-color: yellow;
       border-color: black;
       color: black;
     }
     .btn-primary:hover{
       background-color: black;
       border-color: yellow;
       color: yellow;
     }
     body{margin-top:20px;
color: black;
    background: black;
}
.account-settings .user-profile {
    margin: 0 0 1rem 0;
    padding-bottom: 1rem;
    text-align: center;
}
.account-settings .user-profile .user-avatar {
    margin: 0 0 1rem 0;
}
.account-settings .user-profile .user-avatar img {
    width: 90px;
    height: 90px;
    -webkit-border-radius: 100px;
    -moz-border-radius: 100px;
    border-radius: 100px;
}
.account-settings .user-profile h5.user-name {
    margin: 0 0 0.5rem 0;
}
.account-settings .user-profile h6.user-email {
    margin: 0;
    font-size: 0.8rem;
    font-weight: 400;
}
.account-settings .about {
    margin: 1rem 0 0 0;
    font-size: 0.8rem;
    text-align: center;
}
.card {
    background: yellow;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    border-radius: 5px;
    border: 0;
    margin-bottom: 1rem;
}
.form-control {
    border: 1px solid #596280;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    border-radius: 2px;
    font-size: .825rem;
    background: #1A233A;
    color: #bcd0f7;
}
     </style>
   </head>
   <body>

<?php
$email = $_SESSION['driverEmail'];
$query = "select * from driver where email = '$email'";
$result = $conn->query($query);

$row = $result->fetch_assoc();
$name = $row['name'];
$pass = $row['password'];
$add = $row['address'];
$phone = $row['phone'];
 ?>
<form class="" action="driverSettings.php" method="post">
 <div class="container">
 <div class="row gutters">
 	<div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
 		<div class="card h-100">
 			<div class="card-body">
 				<div class="account-settings">
 					<div class="user-profile">
 						<div class="user-avatar">
 							<img src="images\driverImage.png" alt="User Driver">
 						</div>
 						<h5 class="user-name"><?php echo $row['name']; ?></h5>
 						<h6 class="user-email"><?php echo $row['email']; ?></h6>
 					</div>
 					<div class="about">
 						<h5 class="mb-2 text-primary">About</h5>
 						<p>Driver.</p>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>



 	<div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
 		<div class="card h-100">
 			<div class="card-body">
 				<div class="row gutters">
 					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
 						<h6 class="mb-3 text-primary">Account Details</h6>
 					</div>
 					<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
 						<div class="form-group">
 							<label for="fullName">Full Name</label>
 							<input name="fullname" type="text" class="form-control" id="fullName" placeholder="Enter full name" value="<?php echo $row['name']; ?>" required>
 						</div>
 					</div>
 					<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
 						<div class="form-group">
 							<label for="eMail">Email</label>
 							<input required name="email" type="email" class="form-control" id="eMail" placeholder="Enter email ID" value="<?php echo $row['email']; ?>">
 						</div>
 					</div>
 					<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
 						<div class="form-group">
 							<label for="phone">Phone</label>
 							<input name="phone" required type="text" class="form-control" id="phone" placeholder="Enter phone number" value="<?php echo $row['phone']; ?>">
 						</div>
 					</div>
 					<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
 						<div class="form-group">
 							<label for="website">Password</label>
 							<input  required name="password" type="password" class="form-control" id="password" placeholder="pasword"  value="<?php echo $row['password']; ?>">
 						</div>
 					</div>
 				</div>
 				<div class="row gutters">
 					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
 						<h6 class="mb-3 text-primary">Address</h6>
 					</div>
 					<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
 						<div class="form-group">
 							<label for="Street">Driver Address</label>
 							<input required name="address" type="name" class="form-control" id="Street" placeholder="Enter Address" value="<?php echo $row['address']; ?>">
 						</div>
 					</div>

 				</div>
 				<div class="row gutters">
 					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
 						<div class="text-right">
 							<button type="submit" id="submit" name="delete" class="btn btn-danger">Delete</button>
 							<button type="submit" id="submit" name="update" class="btn btn-primary">Update</button>
              <?php

                if(isset($_POST['update'])){
                  $email = $_POST['email'];
                  $name = $_POST['fullname'];
                  $pass = $_POST['password'];
                  $add = $_POST['address'];
                  $phone = $_POST['phone'];
                    $query = "UPDATE driver
SET name='$name', email='$email',phone = '$phone',password='$pass',address = '$add'
WHERE email = '$email' ;";
$conn->query($query);
                }
                  if(isset($_POST['delete'])){
                    $email = $_POST['email'];
                    $name = $_POST['fullname'];
                    $pass = $_POST['password'];
                    $add = $_POST['address'];
                    $phone = $_POST['phone'];
                    $query = "DELETE FROM driver WHERE email='$email';";
                    $conn->query();
                  }
               ?>
 						</div>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </div>
 </div>
</form>

 <?php
 require 'passengerDown.php';
  ?>
