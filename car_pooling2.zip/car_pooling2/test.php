<?php
require 'sess.php';
$id = $_POST['FacultyID'];
$img = $_POST['FacultyImage'];

$_SESSION["var1"] = '';
$_SESSION["var3"] = '';
$_SESSION["varABOUTUS"] = '';
 $_SESSION["articles"] = '';




  $filename = $_FILES['FacultyImage']['name'];
    $tempname = $_FILES['FacultyImage']['tmp_name'];
        $folder = "images/".$filename;

        if (move_uploaded_file($tempname, $folder))  {
            $msg = "Image uploaded successfully";
        }else{
            $msg = "Failed to upload image";
            echo $filename;
      }

  $addImage = "UPDATE faculty
SET
    img = '$filename '
WHERE
    id = $id;";
if($conn->query($addImage)){
header("Location:panel.php");
}else{
echo "error!";
}





 ?>
