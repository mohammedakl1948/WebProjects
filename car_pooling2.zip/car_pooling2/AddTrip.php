<?php
require 'checkDriver.php';

 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>Add Trip</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
    <style media="screen">
    .btn-primary,
    .btn-primary:active,
    .btn-primary:visited,
    .btn-primary:focus {
      background-color: yellow;
      border-color: black;
      color: black;
    }
    .btn-primary:hover{
      background-color: black;
      border-color: yellow;
      color: yellow;
    }
    .require {
  color: #666;
}
label small {
  color: #999;
  font-weight: normal;
}
    </style>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


  </head>
  <body>

<div class="container">
<div class="row">

    <div class="col-md-8 col-md-offset-2">

      <h1>Create Trip</h1>

      <form action="AddTrip.php" method="POST">

          <div class="form-group has-error">
              <label for="starttime">Date Time <span class="require">*</span> <small>(Start)</small></label>
              <input type="datetime-local" class="form-control" name="starttime"  required/>

          </div>

          <div class="form-group">
              <label for="arrivetime">Date Time <span class="require">*</span> <small>(Arrive)</small></label>
              <input type="datetime-local" class="form-control" name="arrivetime" required/>
          </div>

          <div class="form-group">
              <label for="startlocation">Location <span class="require">*</span> <small>(Start)</small></label>
            <input type="text" name="startlocation" class="form-control" value=""  placeholder="Start Location" required>
          </div>
          <div class="form-group">
              <label for="Distination">Location <span class="require">*</span> <small>(Distination)</small></label>
            <input type="text" name="distination" class="form-control" value=""  placeholder="Distination" required>
          </div>
          <div class="form-group">
              <label for="DID">Driver-Email <span class="require">*</span> <small>(ID)</small></label>
            <input type="text" name="DID"  class="form-control" value="<?php echo $_SESSION['driverEmail']; ?>"   required disabled>
          </div>

          <div class="form-group">
              <label for="maxpassengers">Number of Passengers <span class="require">*</span> <small>(number of dseats in the car)</small></label>
            <input type="number" name="maxpassengers" class="form-control" value=""  placeholder="Number of Passengers" required>
          </div>

          <div class="form-group">
              <label for="Status">Status <span class="require">*</span> <small>(Trip status)</small></label>
            <input type="text" name="Status" class="form-control" value="progress"  placeholder="" required disabled>
          </div>

          <div class="form-group">
              <p><span class="require">*</span> - required fields</p>
          </div>

          <div class="form-group">

              <input type="reset" name="reset" value="Reset" class="btn btn-danger">
              <input type="submit" name="create" value="Create" class="btn btn-primary">
          </div>

      </form>
  </div>
<?php
$ip = $_SERVER['REMOTE_ADDR'];

        // create curl resource
        $ch = curl_init();

        // set url
        curl_setopt($ch, CURLOPT_URL, "https://api.ipgeolocation.io/ipgeo?apiKey=83fb122acfb9438c9337b69fd2f9e2c9&ip=".$ip);

        //return the transfer as a string
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        // $output contains the output string
        $output = curl_exec($ch);

        // close curl resource to free up system resources
        curl_close($ch);
        echo $ip;
function formatDateTime($datetime) {
  $var = "";
  for($i = 0 ; $i < strlen($datetime) ; $i++){
      if($datetime[$i]=='T'){
        $var.=" ";
      }else{
        $var.=$datetime[$i];
      }
  }
  $var.=":00";
  return $var;
}
    if(isset($_POST['create'])){

        $starttime = formatDateTime($_POST['starttime']);
        $arrivetime =  formatDateTime($_POST['arrivetime']);
        $nbofPass = $_POST['maxpassengers'];
        $DID  = $_SESSION['driverEmail'];
        $startLocation = $_POST['startlocation'];
        $distination = $_POST['distination'];
        $status  = "progress";
        $query = "INSERT INTO trip (datee, starttime, arrivetime, startinglocation, destination, DID, maxPassengers, status) VALUES (NOW(), '$starttime', '$arrivetime', '$startLocation', '$distination', '$DID', '$nbofPass', 'progress');";

        if($conn->query($query)){

        }else {
          header("Location:Fail.php");
        }
    }


 ?>
</div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<!-- javascript -->
<script src="js/owl.carousel.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
<script>
  </body>
</html>
