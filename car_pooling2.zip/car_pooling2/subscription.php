<?php
require 'connection.php';
$email = $_POST['emailNews'];
$query = "INSERT INTO newsletter (emailid) VALUES ('$email');";
if($conn->query($query)){
  header("Location:Succesful.php");
}else{
  header("Location:Fail.php");
}
?>
