<?php
require 'checkDriver.php';
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<!-- site metas -->
<title>Requests</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content="">
<!-- bootstrap css -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<!-- style css -->
<link rel="stylesheet" type="text/css" href="css/style.css">
<!-- Responsive-->
<link rel="stylesheet" href="css/responsive.css">
<!-- fevicon -->
<link rel="icon" href="images/fevicon.png" type="image/gif" />
<!-- Scrollbar Custom CSS -->
<link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
<!-- Tweaks for older IEs-->
<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
<!-- owl stylesheets -->
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
<style media="screen">
.btn-primary,
.btn-primary:active,
.btn-primary:visited,
.btn-primary:focus {
  background-color: yellow;
  border-color: black;
  color: black;
}
.btn-primary:hover{
  background-color: black;
  border-color: yellow;
  color: yellow;
}
h2{
  color: yellow;

}
body{
  background-color: black;
  color:black;
}
li{
  background-color: yellow;
  border-radius: 25px;

}
.btn-success,
.btn-success:active,
.btn-success:visited,
.btn-success:focus {
  background-color: green;
  border-color: yellow;
  color: black;
}
</style>
  </head>


  <body>
    <?php
    $driveridquery = "SELECT * FROM trip where DID='$DID';";
    $result = $conn->query($driveridquery);
    while($row=$result->fetch_assoc()){
        $tid = $row['TID'];
        $tidlocation = $row['destination'];
        $query = "SELECT * FROM requests where TID='$tid';";
        $result2 = $conn->query($query);
        echo "<link href=\"https://fonts.googleapis.com/css2?family=Oswald:wght@600&display=swap\" rel=\"stylesheet\">

<section class=\"news pt-0\">
  <div class=\"container mt-md-5\">
    <h2 class=\"mx-4 my-0 text-center\">TRIP to $tidlocation</h2><ul class=\"row d-lg-flex list-unstyled image-block justify-content-center px-lg-0 mx-lg-0\">";
        while($row2 = $result2->fetch_assoc()){
          $rid = $row2['ID'];
          $pid = $row2['PEmail'];

          $pass = "SELECT * FROM passenger where email = '$pid';";
          $passres = $conn->query($pass);
          $row3 = $passres->fetch_assoc();
          $pname = $row3['name'];
          $pphone = $row3['phonenumber'];
            echo "


          <li class=\"col-lg-4 col-md-5 image-block full-width p-3\">
          <form class=\"\" action=\"acceptRequest.php?tid=$tid&pid=$pid&rid=$rid&did=$DID\" method=\"post\">
            <div class=\"image-block-inner\">
              <a class=\"mh-100\" href=\"#\">

                </a>
              <span class=\"hp-posts-cat\">Request</span>
              <h4 class=\"mt-3\"><a href=\"#\">The Passenger ($pid) whith phone number ($pphone) has requeste to join your trip.</a></h4>
              <!--  <p></p> -->
              <input class = \"btn-success\" type=\"submit\" name=\"accept\" value=\"Accept\"> <input type=\"submit\" name=\"delete\" value=\"Reject\" class=\"btn-danger\">
            </div><!-- .image-block-inner --></form></li>
          ";
        }
        echo "
      </ul>
    </div>
  </section>";
    }



     ?>

     <script src="js/jquery.min.js"></script>
     <script src="js/popper.min.js"></script>
     <script src="js/bootstrap.bundle.min.js"></script>
     <script src="js/jquery-3.0.0.min.js"></script>
     <script src="js/plugin.js"></script>
     <!-- sidebar -->
     <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
     <script src="js/custom.js"></script>
     <!-- javascript -->
     <script src="js/owl.carousel.js"></script>
     <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
     <script>
     $(document).ready(function(){
     $(".fancybox").fancybox({
     openEffect: "none",
     closeEffect: "none"
     });

     $(".zoom").hover(function(){

     $(this).addClass('transition');
     }, function(){

     $(this).removeClass('transition');
     });
     });
     </script>
     <script>
     function openNav() {
     document.getElementById("myNav").style.width = "100%";
     }

     function closeNav() {
     document.getElementById("myNav").style.width = "0%";
     }
     </script>
  </body>
</html>
