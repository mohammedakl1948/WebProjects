<?php
require 'connection.php';
session_start();
if(empty($_SESSION["driverEmail"])){
header("Location:index.php");
}
$DID = $_SESSION['driverEmail'];


 ?>
