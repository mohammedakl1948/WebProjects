<?php
require 'connection.php';
session_start();
if(empty($_SESSION["passengerEmail"])){
header("Location:index.php");
}



 ?>
