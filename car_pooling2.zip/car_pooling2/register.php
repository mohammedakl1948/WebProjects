<?php
require 'connection.php';
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$name = $firstname."".$lastname;
$Email = $_POST['email'];
$tel = $_POST['tele'];
$address = $_POST['address'];
$password = $_POST['password'];
$userType = $_POST['userType'];

if($userType=="driver"){
  $query = "INSERT INTO driver (name, phone, email, password, address) VALUES ('$name', '$tel', '$Email', '$password', '$address');";
}else{
  $query = "INSERT INTO passenger (name, email, phonenumber, pass, address) VALUES ('$name', '$Email', '$tel', '$password', '$address')";
}

require 'checkQuery.php';

 ?>
