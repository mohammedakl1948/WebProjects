<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
      </head>
      <style media="screen">
      * {
 margin: 0;
 padding: 0;
 box-sizing: border-box;
}
        nav{

          width: 100%;
          height: 60px;
          background-color: #DD6E0F;
        }
        a{
          text-decoration: none;
          color: white;
          font-size: 50px;
          font-family: fantasy;
        }
        .installation{
          display: inline-block;
          width: 40%;
          margin-top: 2%;
          background-color: white;
          border: 2px solid #DD6E0F;
          border-radius: 25px;
          height: 500px;
          margin-left: 6%;
          float: left;
        }
        .Registration{
          display: inline-block;
          width: 40%;
          border: 2px solid #DD6E0F;
          border-radius: 25px;
          height: 500px;
          margin-top: 2%;
          margin-left: 5%;
        }
        .registerButton{
          margin-top: 5%;
          color: white;
          background-color: #DD6E0F;
          border: none;
          padding: 10px;
          font-size: 18px;
          border-radius: 25px;
          margin-left: 40%;
        }
        .registerButton:hover{
          color: #DD6E0F;
          background-color: white;

        }
        .name{
          background-color: white;
          border-radius: 25px;
          border: 2px solid #DD6E0F;
          padding: 10px;
          margin-top: 12%;
          margin-left: 12%;
        }

        .email,.phone,.address{
          margin-top: 10px;
          margin-left: 12%;
          background-color: white;
          border-radius: 25px;
          border:2px solid #DD6E0F;
          padding: 10px;
          width: 82%;
        }
        .adli,.id{

          margin-top: 5%;
        }
        .id{
          margin-left: 12%;
        }
        .adli{

          margin-left: -9%;
        }
        .head,.ins{
          margin-top: 10%;
          margin-left: 40%;
          color: orange;

        }
        .ins{
          margin-left: 35%;
        }
      </style>
  <body>
  <nav  style="background-color:#DD6E0F;">
      <a class="navbar-brand" href="index.php">Car Pooling</a>
    </nav>
    <div class="installation">
      <h1 class="ins"> Installation </h1>

    </div>
    <div class="Registration">
      <h1 class="head">Hello :)</h1>
      <form class="" action="register.php" method="post">
        <input type="text" name="firstname" value="" placeholder="First Name" required class="name"> <input type="text" name="lastname" value="" placeholder="Last Name" required class="name" style="margin-left:9%;"> <br>
        <input type="email" name="email" value="" placeholder="Email" required class="email"><br>
        <input type="tel" name="tele" value="" class="phone" placeholder="Mobile Number (+961123456)" required><br>
        <input type="text" name="address" value="" class="address" placeholder="Address"><br>
        <input type="file" name="adlirecord" value="" class="id" required> <input type="file" name="idcard" value="" required class="adli">
        <br> <input type="submit" name="register" value="Register" class="registerButton">
      </form>
    </div>
  </body>
</html>
