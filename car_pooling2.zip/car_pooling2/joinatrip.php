<?php
require 'checkPass.php';
$pID = $_REQUEST['pid'];
$tiD = $_REQUEST['TID'];
$did = $_REQUEST['did'];
$number = $_REQUEST['number'];
$max = $_REQUEST['max'];
$query = "INSERT INTO requests (PEmail, TID) VALUES ('$pID', '$tiD') ;";
$select = "SELECT PID FROM trippassengers where TID = $tiD;";
$result = $conn->query($select);
$row = $result->fetch_assoc();
if(($row['PID']!=$pID || empty($row['PID'])) && $number<$max){
if($conn->query($query)){
  header("Location:Succesful.php");
}else{
  header("Location:Fail.php");
}
}else {
  header("Location:Fail.php");

}
 ?>
