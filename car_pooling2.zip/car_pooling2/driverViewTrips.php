<?php
require 'checkDriver.php';

 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <!-- mobile metas -->
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="viewport" content="initial-scale=1, maximum-scale=1">
     <!-- site metas -->
     <title>Driver</title>
     <meta name="keywords" content="">
     <meta name="description" content="">
     <meta name="author" content="">
     <!-- bootstrap css -->
     <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
     <!-- style css -->
     <link rel="stylesheet" type="text/css" href="css/style.css">
     <!-- Responsive-->
     <link rel="stylesheet" href="css/responsive.css">
     <!-- fevicon -->
     <link rel="icon" href="images/fevicon.png" type="image/gif" />
     <!-- Scrollbar Custom CSS -->
     <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
     <!-- Tweaks for older IEs-->
     <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
     <!-- owl stylesheets -->
     <link rel="stylesheet" href="css/owl.carousel.min.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">

     <title>My Trips</title>
     <style media="screen">
     body{
    background:black;
    }

    p {
      font-size: 14px;
      color: #777;
    }

    .blog .image {
      height: 250px;
      overflow: hidden;
      border-radius: 3px 0 0 3px;
    }

    .blog .image img {
      width: 100%;
      height: auto;
    }

    .blog .date {
      top: -10px;
      z-index: 99;
      width: 65px;
      right: -10px;
      height: 65px;
      padding: 10px;
      position: absolute;
      color:black;
      font-weight:bold;
      background: yellow;
      border-radius: 999px;
    }

    .blog .blog-details {
      padding: 0 20px 0 0;
    }

    .blog {
      padding: 0;
    }

    .well {
      border: 0;
      padding: 20px;
      min-height: 63px;
      background: #fff;
      box-shadow: none;
      border-radius: 3px;
      position: relative;
      max-height: 100000px;
      border-bottom: 2px solid #ccc;
    }

    .blog .blog-details h2 {
      margin-bottom: 10px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }

    .blog .date .blog-number {
      color: black;
      display: block;
      font-size: 24px;
      text-align: center;
    }
    .btn-primary,
    .btn-primary:active,
    .btn-primary:visited,
    .btn-primary:focus {
      background-color: yellow;
      border-color: black;
      color: black;
      width: 100%;

    }
    .btn-primary:hover{
      background-color: black;
      border-color: yellow;
      color: yellow;
    }

     </style>

   </head>
   <body>


 <div class="container bootstrap snippets bootdey">
     <hr>



   <div class="row">
     <?php
       $query = "select * from trip where status = 'progress' and arrivetime>NOW() and 	DID  = '$DID';";
       $result = $conn->query($query);
       while($row=$result->fetch_assoc()){
         $tid = $row['TID'];
         $arrivetime = $row['arrivetime'];
         $starttime = $row['starttime'];
         $startinglocation = $row['startinglocation'];
         $distination = $row['destination'];
         $month = date('M', strtotime($starttime));
         $day = date('D', strtotime($starttime));
         $passengers ="Passengers : ";
         $passengersq = "SELECT * FROM passenger where  email in (SELECT PID FROM trippassengers  where TID = $tid);";
         $result2  = $conn->query($passengersq);
         while ($row2=$result2->fetch_assoc()) {
           $pname=$row2['name'];
           $pphone =$row2['phonenumber'];
          $passengers.="$pname($pphone),";
         }
          echo " <form class=\"\" action=\"deleteTrip.php?tid=$tid\" method=\"post\"><div class
           =\"col-xs-12 col-sm-12 col-md-12 col-lg-12\">
               <div class=\"well blog\">
                   <a href=\"#\">
                       <div class=\"date\">
                           <span class=\"blog-date\">$month</span>
                           <span class=\"blog-number\">$day</span>
                       </div>
                       <div class=\"row\">
                           <div class=\"col-xs-12 col-sm-8 col-md-8 col-lg-8\">
                               <div class=\"image\">
                                   <img src=\"images\\trip.jpg\" alt=\"\" style=\"width:600px;\">
                               </div>
                           </div>
                           <div class=\"col-xs-12 col-sm-4 col-md-4 col-lg-4\">
                               <div class=\"blog-details\">
                                   <h2>$distination</h2>
                                   <p>
                                    This Trip starts at $starttime from $startinglocation to $distination and ends at $arrivetime.
                                    <br>$passengers.
                                    </p>
                                    <input type=\"submit\" name=\"join\" value=\"Delete\" class=\"btn-primary\">
                               </div>
                           </div>
                       </div>
                   </a>
               </div>
           </div></form>";
       }
      ?>



   </div>
 </div>                     <?php
include 'driverDown.php';
  ?>
