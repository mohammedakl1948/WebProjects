<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form method="POST" action="googlemaps.php">
    <p>
        <input type="text" name="address" placeholder="Enter address">
    </p>

    <input type="submit" name="submit_address">
</form>
<?php
    if (isset($_POST["submit_address"]))
    {
        $address = $_POST["address"];
        $address = str_replace(" ", "+", $address);
        ?>

        <iframe width="100%" height="500" src="https://maps.google.com/maps?q=<?php echo $address; ?>&output=embed"></iframe>

        <?php
    }
?>
  </body>
</html>
