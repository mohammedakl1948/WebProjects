<!DOCTYPE html>
<?php

require 'sess.php';

 ?>
<html lang="en" dir="lth">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
      input[type=submit]{
        background-color: rgba(255,255,255,0);
        border-style: none;
        width: 100%;
        height: 100%;
        font-size: 15px;
        font-style: oblique;
        font-weight: bold;
        text-align: center;
        padding: 10px;
      }
        input[type=submit]:hover{
              background-color: rgba(0,0,0,0.5);
              color: white;
        }
      *{
        padding: 0;
        margin: 0;
        box-sizing: border-box;
      }
      nav{
        width: 100%;
        height: 60px;
        background-color: black;
        display: inline-block;
      }
      .sidebar{
        height: 100%;
        width: 60px;
        font-size: 30px;
        color:white;
        background-color: black;
        border: none;
      }
      .sidebarmenu{
        float: left;
        height:663px;
        width: 15%;
        background-color: black;

      }
      li{
        color: white;
        padding: 20px;

      }
      a{
        text-decoration: none;
        color: white;
      }
      #sidebar{
        display: none;
        float: left;
      }
      li:hover{
        background-color: rgba(255,255,255,0.5);
      }
      .main{
        float: right;
          width:100%;
          height:603px;

          background-color: red;
          display: inline-block;

      }
      .manageusers,.feedbacks,.thips{
        display: none;
        background-repeat: no-repeat;
        background-size: cover;
        background-image: url('images/background.jpg');
        width: 100%;
        height: 100%;
      }
      h1,h2{
        color: black;
        padding:20px;
      }
      h2{
        padding-left: 40px;
      }
      table{
        margin-left: auto;
        margin-right: auto;
        border:2px solid black;
      }
      th{
        background-color: rgba(0,0,0,0.5);
        color:black;
      }
      th,td{
        padding: 5px;
      }
      tr:hover{
        background-color: rgba(0,0,0,0.2);
      }
      th,th,td{
        border: 2px solid black;
      }
      .main{
        background-repeat: no-repeat;
        background-size: cover;
        background-image: url('images/background.jpg');
      }
      img{
        width: 30px;
        height: 30px;
      }
    </style>
  </head>
  <body>
    <nav id="nav">
      <button type="button" name="button" class="sidebar" onclick="show()">☰</button>
    </nav>
    <div class="sidebarmenu" id="sidebar">
      <ul>
        <li> <a href="#" onclick="showdiv('manageusers')">Manage Users</a> </li>
        <li> <a href="#" onclick="showdiv('feedbacks')">View Feedbacks</a> </li>
        <li> <a href="#" onclick="showdiv('thips')">Manage trips</a> </li>
        <li>  <a href="logout.php" >Log Out</a>  </li>
      </ul>
    </div>
    <div class="main" id="main">
      <div class="manageusers" id="manageusers">
        <h1>Users</h1>
        <h2>Drivers</h2>

        <table>
          <tr>

            <th>
              Name
            </th>
            <th>
              Email
            </th>
            <th>
              Password
            </th>
            <th>
              Phone Number
            </th>
            <th>
              Address
            </th>
            <th>
              Rating
            </th>
            <th>Status</th>
            <th>Block</th>
          </tr>



          <?php
            $query = "SELECT * FROM driver;";
            $result = $conn->query($query);
            while($row = $result->fetch_assoc()){
              $var ="Active";
              $var2="Block";
              $file = "blockDriver.php";
              if($row['status']==1){
                $var2 = "UnBlock";
                $var ="Blocked";
                $file = "unBlockDriver.php";
              }
              $id = $row['email'];
            echo " <form class=\"\" action=\"$file?id=$id\" method=\"post\"> <tr>
                <td>
                  ".$row['name']."
                </td>
                <td name=\"DriverID\">
                  ".$row['email']."
                </td>
                <td>
                  ".$row['password']."
                </td>
                <td>
                  ".$row['phone']."
                </td>
                <td>
                  ".$row['address']."
                </td>
                <td>
                  ".$row['rating']."
                </td>
                <td>
                ".$var."
                </td>
                <td>

                <input type=\"submit\" name=\"\" value=\"$var2\">
                </td>
              </tr>  </form>";

            }
           ?>

        </table>

        <h2>Passengers</h2>

        <table>
          <tr>
            <th>
              Name
            </th>
            <th>
              Email
            </th>
            <th>
              Phone Number
            </th>
            <th>
              Password
            </th>

            <th>
              Address
            </th>
            <th>Status</th>
            <th>Block</th>
          </tr>
          <?php

          $query = "SELECT * FROM passenger;";
          $result = $conn->query($query);
          while($row = $result->fetch_assoc()){
            $var ="Active";
            $var2="Block";
            $file = "blockPassenger.php";
            if($row['status']==1){
              $var2 = "UnBlock";
              $var ="Blocked";
              $file = "unBlockPassenger.php";
            }
            $id = $row['email'];
          echo " <form class=\"\" action=\"$file?id=$id\" method=\"post\"> <tr>
              <td>
                ".$row['name']."
              </td>
              <td>
                ".$row['email']."
              </td>
              <td>
                ".$row['phonenumber']."
              </td>
              <td>
                ".$row['pass']."
              </td>

              <td>
                ".$row['address']."
              </td>

              <td>
              ".$var."
              </td>
              <td>

              <input type=\"submit\" name=\"\" value=\"$var2\">

              </td>
            </tr></form>";

          }

           ?>
        </table>
        <h2>Admins</h2>
        <table>
          <tr>
            <th>
              Email
            </th>
            <th>
              Password
            </th>
          </tr>

          <?php
          $query = "SELECT * FROM admin;";
          $result = $conn->query($query);
          while($row = $result->fetch_assoc()){
            echo "<tr>
              <td>".$row['email']."</td>
              <td>".$row['password']."</td>
            </tr>";
          }
           ?>
        </table>
      </div>
      <div class="feedbacks" id="feedbacks">
        <h1>Feedbacks</h1>
        <table>
          <tr>
            <th>TripID</th>
            <th>PassengerID</th>
            <th>Comment</th>
          </tr>

          <?php
          $query = "SELECT * FROM tripfeedback;";
          $result = $conn->query($query);
          while($row = $result->fetch_assoc()){
            echo "<tr>
              <td>".$row['TID']."</td>
              <td>".$row['pID']."</td>
              <td>".$row['comment']."</td>
            </tr>";
          }
           ?>
        </table>
      </div>
      <div class="thips" id="thips">
        <h1>Trips</h1>
        <table>
          <tr>
            <th>ID</th>
            <th>Date</th>
            <th>StartTime</th>
            <th>ArriveTime</th>
            <th>From</th>
            <th>To</th>
            <th>Driver ID</th>
            <th>Passengers</th>
          </tr>
          <?php
          $query = "SELECT * FROM trip;";
          $result = $conn->query($query);
          while($row = $result->fetch_assoc()){
            $tid = $row['TID'];
            $query2 = "SELECT * FROM trippassengers WHERE TID = '$tid';";
            $result2 = $conn->query($query2);
            $varvar = "";
            while($row2 = $result2->fetch_assoc()){
              $varvar.="<tr>".$row2['PID']."</tr>";
            }
            echo "<tr>
            <td>".$row['TID']."</td>
            <td>".$row['datee']."</td>
            <td>".$row['starttime']."</td>
            <td>".$row['arrivetime']."</td>
            <td>".$row['startinglocation']."</td>
            <td>".$row['destination']."</td>
            <td>".$row['DID']."</td>
            <td>$varvar</td>
            </tr>";
          }
           ?>
        </table>
      </div>
    </div>
    <script type="text/javascript">
    function show() {
      if(document.getElementById('nav').style.width == "85%"){
        document.getElementById('sidebar').style.display="none";
        document.getElementById('nav').style.width = "100%";
        document.getElementById('main').style.width = "100%";
      }else{
          document.getElementById('sidebar').style.display="inline-block";
          document.getElementById('nav').style.width = "85%";
          document.getElementById('main').style.width = "85%";
        }
      }
    </script>
    <script type="text/javascript">
    function showdiv(a) {
      var d = 'feedbacks';
      var b = 'manageusers';
      var c = 'thips';
      if(document.getElementById(a).style.display=="block"){
          document.getElementById(a).style.display= "none";
          document.getElementById(b).style.display= "none";
          document.getElementById(c).style.display= "none";
          document.getElementById(d).style.display= "none";
      }else{
        document.getElementById(b).style.display= "none";
        document.getElementById(c).style.display= "none";
        document.getElementById(d).style.display= "none";
          document.getElementById(a).style.display= "block";
      }

    }

    </script>
  </body>
</html>
