<?php
require 'sess.php';

$adminUser = $_SESSION['ID'];
$pass = $_SESSION['pass'];
$query = "SELECT password FROM admin WHERE email = '$adminUser' ";
$result = $conn->query($query);
if($row=$result->fetch_assoc()){
  if($row['password']==$pass){
      header("Location:adminPanel.php");
  }else{
    session_destroy();
    header("Location:admin.php");
  }
}
?>
