<?php
require '../connection.php';
$id = $_REQUEST['id'];
$query = "UPDATE passenger set status = 1 WHERE email = '$id';";
$conn->query($query);
header("Location:adminPanel.php");
 ?>
