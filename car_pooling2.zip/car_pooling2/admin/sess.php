<?php
require '../connection.php';
session_start();
if(empty($_SESSION["ID"])){
header("Location:admin.php");
}

 ?>
