<!DOCTYPE html>
<?php

session_start();

if(isset($_POST['login'])){
  $username = $_POST['username'];
  $pass = $_POST['password'];
  $_SESSION["ID"] = $username;
  $_SESSION["pass"]=$pass;
  header("Location:checkAdmin.php");
}



 ?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
      .loginpanel{
        top: 50%;
        left:50%;
        transform: translate(-50%,-50%);
        position: absolute;
        width: 15.5%;
        height: 40%;
      }
      h1{
        color: black;
        border-bottom: 2px solid black;
      }
      input{
        margin-top: 10px;
        width: 200px;
        height: 20px;
        padding: 5px;
        border: none;
      }
      .sub{
        width:212px;
        height: 25px;
        background: black;
        color: white;
      }
      .sub:hover{
        color: black;
        background-color: white;
      }
      .user,.pass{
        background-color: rgba(0,0,0,0.6);
        color: rgba(255,255,255,0.8);
        border-bottom: 2px solid black;
      }
      ::placeholder{
        color: rgba(255,255,255,0.8);
      }
      body{
        background-image: url('images/background.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        width: 100%;
        height:100%;
      }
    </style>
  </head>
  <body>
    <div class="loginpanel">
      <h1>Admin</h1>
      <form class="" action="admin.php" method="post">
        <input type="text" name="username" value="" required placeholder="UserName" class="user"><br>
        <input type="password" name="password" value="" required placeholder="Password" class="pass"><br>
        <input type="submit" name="login" value="Log In" class="sub"><br>
      </form>
    </div>
  </body>
</html>
