<?php
require 'checkDriver.php';
$tid = $_REQUEST["tid"];
$delete = "DELETE FROM trip WHERE TID = '$tid';";
if($conn->query($delete)){
  header("Location:driverViewTrips.php");
}else{
  header("Location:Fail.php");
}
?>
