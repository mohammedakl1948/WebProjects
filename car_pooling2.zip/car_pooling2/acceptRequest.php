<?php
require 'checkDriver.php';
include 'driverUp.php';

$trip = $_REQUEST['tid'];
$rid = $_REQUEST['rid'];
$pid = $_REQUEST['pid'];

$query1 = "INSERT INTO trippassengers (driverID , PID , TID) VALUES ('$DID' , '$pid' , $trip); ";
$query2 = "DELETE FROM requests where ID = $rid;";

if(isset($_POST['accept'])){
  $conn->query($query1);
  $conn->query($query2);
  header("Location:requests.php");
}
else if(isset($_POST['delete'])){
  $conn->query($query2);
  header("Location:requests.php");
}else{
  header("Location:Fail.php");
}
 ?>
